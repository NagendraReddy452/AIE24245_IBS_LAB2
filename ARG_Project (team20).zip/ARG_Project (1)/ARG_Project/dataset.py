import pandas as pd
from features import extract_features

def load_data():

    df = pd.read_csv("data/data.csv")

    X = []

    for seq in df["sequence"]:

        X.append(extract_features(seq))

    y = df["label"]

    return X, y
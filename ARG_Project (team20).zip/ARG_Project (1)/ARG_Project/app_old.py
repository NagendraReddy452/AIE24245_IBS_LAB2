import os
import json
import joblib
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix
)


# ── Paths ─────────────────────────────────────────
BASE_DIR = os.path.dirname(
    os.path.abspath(__file__)
)

DATA_PATH = os.path.join(
    BASE_DIR,
    "data",
    "data.csv"
)

MODEL_DIR = os.path.join(
    BASE_DIR,
    "models"
)

MODEL_PATH = os.path.join(
    MODEL_DIR,
    "model.pkl"
)

METRICS_PATH = os.path.join(
    MODEL_DIR,
    "metrics.json"
)

os.makedirs(
    MODEL_DIR,
    exist_ok=True
)


# ── Feature extraction ───────────────────────────
AMINO_ACIDS = "ACDEFGHIKLMNPQRSTVWY"


def extract_features(seq):

    seq = str(seq).strip().upper()

    n = len(seq)

    features = []


    # sequence length
    features.append(
        n
    )


    # amino acid frequency
    for aa in AMINO_ACIDS:

        features.append(

            seq.count(aa) / n

        )


    # dipeptide features
    for aa1 in AMINO_ACIDS:

        for aa2 in AMINO_ACIDS:

            pair = aa1 + aa2

            count = seq.count(
                pair
            )

            features.append(

                count / max(
                    1,
                    n - 1
                )

            )

    return features


# ── Load dataset ─────────────────────────────────
print(
    "Loading dataset..."
)

df = pd.read_csv(
    DATA_PATH
)

print(
    f"Samples loaded: {len(df)}"
)


# ── Prepare data ─────────────────────────────────
print(
    "Extracting features..."
)

X = df[
    "sequence"
].apply(
    extract_features
).tolist()

y = df[
    "label"
]


# ── Train/test split ─────────────────────────────
X_train, X_test, y_train, y_test = train_test_split(

    X,
    y,

    test_size=0.2,

    random_state=42,

    stratify=y

)


# ── Train model ──────────────────────────────────
print(
    "Training Random Forest..."
)

model = RandomForestClassifier(

    n_estimators=500,

    random_state=42,

    n_jobs=-1

)

model.fit(

    X_train,

    y_train

)


# ── Predictions ──────────────────────────────────
y_pred = model.predict(
    X_test
)


# ── Save model ───────────────────────────────────
joblib.dump(

    model,

    MODEL_PATH

)

print(
    "model.pkl saved"
)


# ── Metrics ──────────────────────────────────────
metrics = {

    "accuracy": round(

        accuracy_score(

            y_test,

            y_pred

        ) * 100,

        2

    ),

    "classes": list(
        model.classes_
    ),

    "report": classification_report(

        y_test,

        y_pred,

        output_dict=True

    ),

    "confusion_matrix": confusion_matrix(

        y_test,

        y_pred

    ).tolist()

}


# ── Save metrics ─────────────────────────────────
with open(

    METRICS_PATH,

    "w"

) as f:

    json.dump(

        metrics,

        f,

        indent=4

    )


print(
    "metrics.json saved"
)

print(
    "Training complete"
)
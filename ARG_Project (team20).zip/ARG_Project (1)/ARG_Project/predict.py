import joblib
import os
from features import extract_features

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "models", "model.pkl")

model = joblib.load(MODEL_PATH)

def predict_sequence(seq: str) -> tuple:
    """
    Predict the antibiotic resistance class of a protein sequence.

    Returns:
        (prediction: str, confidence: float)  e.g. ("Beta-Lactam", 87.42)
    """
    features = [extract_features(seq)]
    prediction = model.predict(features)[0]
    probability = max(model.predict_proba(features)[0])
    return prediction, round(probability * 100, 2)
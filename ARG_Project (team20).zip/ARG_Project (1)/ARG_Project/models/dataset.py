import pandas as pd
from features import extract_features

def load_data():
df = pd.read_csv("../data/data.csv")
    X = []
    for seq in df["sequence"]:
        X.append(extract_features(seq))

    y = df[["beta_lactam", "tetracycline", "macrolide"]].values

    return X, y
if __name__ == "__main__":
    X, y = load_data()
    print(len(X), "samples loaded")
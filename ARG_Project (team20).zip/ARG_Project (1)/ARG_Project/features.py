AMINO_ACIDS = "ACDEFGHIKLMNPQRSTVWY"

def extract_features(seq: str) -> list:
    seq = seq.strip().upper()
    n = len(seq)
    if n == 0:
        raise ValueError("Cannot extract features from an empty sequence.")
    features = [n]
    for aa in AMINO_ACIDS:
        features.append(seq.count(aa) / n)
    return features
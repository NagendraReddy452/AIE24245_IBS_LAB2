CLASS_INFO = {

    "Beta-Lactam": {
        "description": "Resistance against beta-lactam antibiotics.",
        "examples": "Penicillin, Amoxicillin, Cephalosporins",
        "mechanism": "Produces beta-lactamase enzymes.",
        "clinical": "Common in hospital-acquired infections."
    },

    "Tetracycline": {
        "description": "Resistance against tetracycline antibiotics.",
        "examples": "Tetracycline, Doxycycline",
        "mechanism": "Efflux pumps or ribosomal protection.",
        "clinical": "Common in livestock and environmental bacteria."
    },

    "Macrolide": {
        "description": "Resistance against macrolide antibiotics.",
        "examples": "Erythromycin, Azithromycin",
        "mechanism": "Target modification or drug efflux.",
        "clinical": "Common in respiratory pathogens."
    }

}
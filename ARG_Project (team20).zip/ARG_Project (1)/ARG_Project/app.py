from class_info import CLASS_INFO
import streamlit as st
import joblib
import os
import json
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


# ── Page config ─────────────────────────────────────────
st.set_page_config(
    page_title="Antibiotic Resistance Predictor",
    page_icon="🧬",
    layout="centered"
)


# ── Paths ───────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "models", "model.pkl")
METRICS_PATH = os.path.join(BASE_DIR, "models", "metrics.json")


# ── Load model ──────────────────────────────────────────
@st.cache_resource
def load_model():

    if not os.path.exists(MODEL_PATH):
        st.error("Model not found.")
        st.stop()

    return joblib.load(MODEL_PATH)


def load_metrics():

    if not os.path.exists(METRICS_PATH):
        return None

    with open(METRICS_PATH) as f:
        return json.load(f)


model = load_model()


# ── Feature extraction ──────────────────────────────────
AMINO_ACIDS = "ACDEFGHIKLMNPQRSTVWY"


def extract_features(seq):

    seq = seq.strip().upper()

    n = len(seq)

    features = [n]

    for aa in AMINO_ACIDS:
        features.append(
            seq.count(aa) / n
        )

    return features


def validate_sequence(seq):

    seq = seq.strip().upper()

    if not seq:
        return False, "Please enter a sequence."

    if len(seq) < 10:
        return False, "Sequence too short."

    invalid = set(seq) - set(AMINO_ACIDS)

    if invalid:
        return False, f"Invalid characters: {', '.join(invalid)}"

    return True, ""


# ── FASTA parser ────────────────────────────────────────
def parse_fasta(text):

    records = []

    header = ""
    seq = ""

    for line in text.splitlines():

        line = line.strip()

        if line.startswith(">"):

            if header and seq:
                records.append((header, seq))

            header = line[1:]
            seq = ""

        else:
            seq += line

    if header and seq:
        records.append((header, seq))

    return records


# ── Branding ────────────────────────────────────────────
st.title("🧬 Antibiotic Resistance Gene Predictor")

st.markdown(
    "### Machine Learning Based Multi-Class Classification"
)

st.markdown(
    "**Developed by Varshini**"
)

st.divider()


# ── Tabs ────────────────────────────────────────────────
tab1, tab2, tab3 = st.tabs([
    "Single Sequence",
    "Batch Prediction",
    "Model Performance"
])


# TAB 1
with tab1:

    sequence = st.text_area(
        "Enter Protein Sequence",
        height=200
    )

    if st.button(
        "Predict",
        type="primary",
        use_container_width=True
    ):

        valid, error_msg = validate_sequence(
            sequence
        )

        if not valid:

            st.warning(error_msg)

        else:

            features = [
                extract_features(
                    sequence
                )
            ]

            prediction = model.predict(
                features
            )[0]

            probabilities = model.predict_proba(
                features
            )[0]

            class_labels = model.classes_

            confidence = max(
                probabilities
            ) * 100


            st.subheader(
                "Prediction Result"
            )

            st.success(
                f"Predicted Resistance Type: **{prediction}**"
            )

            st.info(
                f"Confidence Score: **{confidence:.2f}%**"
            )


            info = CLASS_INFO[
                prediction
            ]


            st.subheader(
                "Class Description"
            )

            st.write(
                "📌 Description:",
                info["description"]
            )

            st.write(
                "💊 Examples:",
                info["examples"]
            )

            st.write(
                "⚙️ Mechanism:",
                info["mechanism"]
            )

            st.write(
                "🏥 Clinical Importance:",
                info["clinical"]
            )


            st.markdown(
                "**Confidence by class**"
            )

            fig, ax = plt.subplots(
                figsize=(6, 2.5)
            )

            ax.barh(
                class_labels,
                probabilities * 100
            )

            ax.set_xlim(
                0,
                100
            )

            ax.set_xlabel(
                "Confidence (%)"
            )

            fig.tight_layout()

            st.pyplot(
                fig,
                use_container_width=True
            )

            plt.close(fig)


# TAB 2
with tab2:

    uploaded_file = st.file_uploader(
        "Upload FASTA file",
        type=["fasta", "fa", "txt"]
    )

    if uploaded_file:

        text = uploaded_file.read().decode(
            "utf-8",
            errors="ignore"
        )

        records = parse_fasta(
            text
        )

        if st.button(
            "Run Batch Prediction"
        ):

            results = []

            for header, seq in records:

                feats = [
                    extract_features(
                        seq
                    )
                ]

                pred = model.predict(
                    feats
                )[0]

                probs = model.predict_proba(
                    feats
                )[0]

                results.append({

                    "ID": header,

                    "Prediction": pred,

                    "Confidence (%)":
                        round(
                            max(probs) * 100,
                            2
                        )

                })

            df = pd.DataFrame(
                results
            )

            st.dataframe(
                df,
                use_container_width=True
            )


# TAB 3
with tab3:

    metrics = load_metrics()

    if metrics is None:

        st.warning(
            "Metrics not found."
        )

    else:

        classes = metrics["classes"]

        cm = np.array(
            metrics[
                "confusion_matrix"
            ]
        )


        st.subheader(
            "Confusion Matrix"
        )

        fig3, ax3 = plt.subplots(
            figsize=(6, 5)
        )

        im = ax3.imshow(
            cm,
            cmap="Blues"
        )

        ax3.set_xticks(
            range(
                len(classes)
            )
        )

        ax3.set_yticks(
            range(
                len(classes)
            )
        )

        ax3.set_xticklabels(
            classes
        )

        ax3.set_yticklabels(
            classes
        )

        threshold = cm.max() / 2

        for i in range(
            len(classes)
        ):

            for j in range(
                len(classes)
            ):

                ax3.text(
                    j,
                    i,
                    str(cm[i, j]),
                    ha="center",
                    va="center",
                    color=(
                        "white"
                        if cm[i, j] > threshold
                        else "black"
                    )
                )

        plt.colorbar(
            im
        )

        st.pyplot(
            fig3
        )

        plt.close(
            fig3
        )


        st.subheader(
            "Feature Importance"
        )

        importance = model.feature_importances_

        feature_names = [
            "Length"
        ] + list(
            AMINO_ACIDS
        )

        fig4, ax4 = plt.subplots()

        ax4.bar(
            feature_names,
            importance
        )

        ax4.tick_params(
            axis="x",
            rotation=45
        )

        st.pyplot(
            fig4
        )

        plt.close(
            fig4
        )


st.divider()

st.caption(
    "ARG Predictor · For research use only"
)
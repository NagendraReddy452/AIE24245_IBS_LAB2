import pandas as pd

sequences = []
labels = []

with open("data/data.fasta", "r") as f:

    seq = ""
    label = ""

    for line in f:

        line = line.strip()

        if line.startswith(">"):

            if seq:
                sequences.append(seq)
                labels.append(label)

            seq = ""

            line_lower = line.lower()

            if "beta" in line_lower or "lactam" in line_lower:
                label = "Beta-Lactam"

            elif "tetracycline" in line_lower or "tet" in line_lower:
                label = "Tetracycline"

            elif "macrolide" in line_lower or "erm" in line_lower:
                label = "Macrolide"

            else:
                label = "Unknown"

        else:
            seq += line

    if seq:
        sequences.append(seq)
        labels.append(label)

df = pd.DataFrame({
    "sequence": sequences,
    "label": labels
})

df.to_csv("data/data.csv", index=False)

print("✅ CSV dataset created!")